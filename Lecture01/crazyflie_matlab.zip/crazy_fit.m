close all
load thrustdata

p1 = polyfit(x,y,1);
p2 = polyfit(x,y,2);
p4 = polyfit(x,y,4);
p10 = polyfit(x,y,10);
xval = 0:1e2:25e3;

figure(1)
plotfix
hold on
plot(x,y,'b.','MarkerSize',20)
title('Thrust vs Rotor Speed')
xlabel('Rotor Speed [rpm]')
ylabel('Thrust [N]')
plot(xval,polyval(p1,xval),'r-')
legend('measurements','polynomial order 1','Location','North')
axis([0 25e3 -0.02 0.18])
e1 = y - polyval(p1,x);
J1 = sum(e1.^2)
%print -depsc crazy01.eps

figure(2)
plotfix
hold on
plot(x,y,'b.','MarkerSize',20)
title('Thrust vs Rotor Speed')
xlabel('Rotor Speed [rpm]')
ylabel('Thrust [N]')
plot(xval,polyval(p2,xval),'r-')
legend('measurements','polynomial order 2','Location','North')
axis([0 25e3 -0.02 0.18])
e2 = y - polyval(p2,x);
J2 = sum(e2.^2)
%print -depsc  crazy02.eps

figure(4)
plotfix
hold on
plot(x,y,'b.','MarkerSize',20)
title('Thrust vs Rotor Speed')
xlabel('Rotor Speed [rpm]')
ylabel('Thrust [N]')
%plot(x,polyval(p3,x),'b-','Linewidth',2)
plot(xval,polyval(p4,xval),'r')
legend('measurements','polynomial order 4','Location','North')
axis([0 25e3 -0.02 0.18])
e4 = y - polyval(p4,x);
J4 = sum(e4.^2)
%print -depsc  crazy04.eps

figure(10)
plotfix
hold on
plot(x,y,'b.','MarkerSize',20)
title('Thrust vs Rotor Speed')
xlabel('Rotor Speed [rpm]')
ylabel('Thrust [N]')
plot(xval,polyval(p10,xval),'r-')
legend('measurements','polynomial order 10','Location','North')
axis([0 25e3 -0.02 0.18])
e10 = y - polyval(p10,x);
J10 = sum(e10.^2)
%print -depsc  crazy10.eps



